# 个人舞蹈曲库 V1.5｜SDD 开发计划包 V1.1

本包为 2026-10-02 交叉复核后的正式开发输入。

## 开发读取顺序

1. `.specify/memory/constitution.md`
2. `specs/001-personal-dance-library/spec.md`
3. `specs/001-personal-dance-library/plan.md`
4. `specs/001-personal-dance-library/tasks.md`
5. supporting docs / contracts
6. `docs/ui/ui-assets-manifest.md` + approved images
7. 连续开发提示词

## 重要版本结论

- Stable Capacitor: v8.x
- Android: minSdk 24 / compileSdk 36 / targetSdk 36
- Node: 22+
- UI: light + dark；dark approved 为主视觉
- Development: USB ADB live reload + early debug APK prebuild
- Human Gate: only after all development tasks

详见 `docs/verification/sdd-cross-check.md`。
